#!/usr/bin/perl
# Notchling: отвечать на разрешения и вопросы Claude Code прямо из чёлки.
# Хук синхронный: отправляет запрос в приложение по локальному Unix-сокету и ждёт ответа.
# Если приложение не запущено, не ответило или пользователь выбрал «В чат», ничего не печатает:
# тогда Claude Code спрашивает сам, как обычно. Сеть не используется.
use strict;
use warnings;
use utf8;                      # русские строки в самом скрипте — символы, а не байты
use JSON::PP;
use Socket qw(SOCK_STREAM);
use IO::Socket::UNIX;

$SIG{ALRM} = sub { exit 0 };
alarm 130;

my $raw = do { local $/; <STDIN> } // '';
my $event = eval { JSON::PP->new->utf8->decode($raw) };
exit 0 unless ref $event eq 'HASH';

my $name = $event->{hook_event_name} // '';
my $tool = $event->{tool_name} // '';
my $kind;
if    ($name eq 'PermissionRequest' && $tool ne 'AskUserQuestion') { $kind = 'permission' }
elsif ($name eq 'PreToolUse'        && $tool eq 'AskUserQuestion') { $kind = 'question' }
elsif ($name eq 'Stop')                                           { $kind = 'reply' }
else { exit 0 }

my $input = ref $event->{tool_input} eq 'HASH' ? $event->{tool_input} : {};
my %short;
if ($kind eq 'reply') {
    # Ход закончен: показываем последнее сообщение агента и ждём текст пользователя.
} elsif ($kind eq 'question') {
    $short{questions} = $input->{questions};
} else {
    for my $key (qw(command description file_path notebook_path url pattern path query)) {
        my $v = $input->{$key};
        $short{$key} = substr($v, 0, 1200) if defined $v && !ref $v;
    }
}
my %request = (
    kind => $kind, session_id => ($event->{session_id} // ''), cwd => ($event->{cwd} // ''),
    tool_name => $tool, tool_input => \%short,
);
$request{agent} = 'codex' if defined $ARGV[0] && $ARGV[0] eq 'codex';   # хук Codex: скрипт зовётся с аргументом codex
if ($kind eq 'reply') {
    my $m = $event->{last_assistant_message};
    $request{last_message} = substr($m, 0, 4000) if defined $m && !ref $m;
}

my $path = "$ENV{HOME}/Library/Application Support/Notchling/ask.sock";
my $sock = IO::Socket::UNIX->new(Type => SOCK_STREAM, Peer => $path) or exit 0;
my $json = JSON::PP->new->utf8->canonical;
print $sock $json->encode(\%request);
$sock->shutdown(1);
my $reply = do { local $/; <$sock> };
close $sock;
exit 0 unless defined $reply && length $reply;
my $answer = eval { JSON::PP->new->utf8->decode($reply) };
exit 0 unless ref $answer eq 'HASH';
my $decision = $answer->{decision} // '';

my %out;
if ($kind eq 'permission' && $decision eq 'allow') {
    %out = (hookSpecificOutput => { hookEventName => 'PermissionRequest', decision => { behavior => 'allow' } });
} elsif ($kind eq 'permission' && $decision eq 'deny') {
    %out = (hookSpecificOutput => { hookEventName => 'PermissionRequest', decision => {
        behavior => 'deny', message => ($answer->{message} // 'Отклонено в Notchling'), interrupt => JSON::PP::false } });
} elsif ($kind eq 'question' && $decision eq 'answer' && ref $answer->{answers} eq 'HASH') {
    %out = (hookSpecificOutput => { hookEventName => 'PreToolUse', permissionDecision => 'allow',
        updatedInput => { questions => $input->{questions}, answers => $answer->{answers} } });
} elsif ($kind eq 'reply' && $decision eq 'text' && defined $answer->{text} && length $answer->{text}) {
    # Stop + block: Claude продолжает работу, а причина становится его следующей инструкцией.
    %out = (decision => 'block', reason => 'Ответ пользователя (из панели Notchling): ' . $answer->{text});
} else {
    exit 0;
}
binmode STDOUT;
print $json->encode(\%out);
exit 0;
