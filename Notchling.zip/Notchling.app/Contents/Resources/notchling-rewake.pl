#!/usr/bin/perl
# Notchling: «написать в сессию из панели в любой момент».
# Запускается фоновым хуком Stop (asyncRewake). Держит локальное соединение с приложением.
# Когда пользователь пишет из панели, хук печатает текст в stderr и выходит с кодом 2:
# Claude Code просыпается и получает текст как напоминание. Если писать не стали, приложение
# закрывает соединение, и хук тихо завершается с кодом 0. Сеть не используется.
use strict;
use warnings;
use utf8;
use JSON::PP;
use Socket qw(SOCK_STREAM);
use IO::Socket::UNIX;

my $raw = do { local $/; <STDIN> } // '';
my $event = eval { JSON::PP->new->utf8->decode($raw) };
exit 0 unless ref $event eq 'HASH' && ($event->{hook_event_name} // '') eq 'Stop';

my $path = "$ENV{HOME}/Library/Application Support/Notchling/ask.sock";
my $sock = IO::Socket::UNIX->new(Type => SOCK_STREAM, Peer => $path) or exit 0;
my %request = (kind => 'wait', session_id => ($event->{session_id} // ''), cwd => ($event->{cwd} // ''));
print $sock JSON::PP->new->utf8->canonical->encode(\%request);
$sock->shutdown(1);

# Блокируемся до ответа приложения или закрытия соединения.
my $reply = do { local $/; <$sock> };
close $sock;
exit 0 unless defined $reply && length $reply;
my $answer = eval { JSON::PP->new->utf8->decode($reply) };
exit 0 unless ref $answer eq 'HASH' && ($answer->{decision} // '') eq 'text';
my $text = $answer->{text};
exit 0 unless defined $text && length $text;

binmode(STDERR, ':encoding(UTF-8)');
print STDERR "Сообщение пользователя (из панели Notchling): $text\n";
exit 2;
