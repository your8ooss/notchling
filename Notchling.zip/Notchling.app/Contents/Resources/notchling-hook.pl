#!/usr/bin/perl
# Notchling: передаёт событие Claude Code в приложение по локальному Unix-сокету.
# Ничего не печатает и всегда завершается с кодом 0, поэтому на работу Claude Code не влияет.
# Если приложение не запущено, событие просто теряется. Сеть не используется.
use strict;
use warnings;
use JSON::PP;
use Socket qw(SOCK_STREAM);
use IO::Socket::UNIX;

$SIG{ALRM} = sub { exit 0 };
alarm 2;

my $raw = do { local $/; <STDIN> } // '';
my $event = eval { JSON::PP->new->utf8->decode($raw) };
exit 0 unless ref $event eq 'HASH';

my %out;
for my $key (qw(session_id cwd hook_event_name tool_name notification_type message title
                reason error source prompt last_assistant_message permission_mode)) {
    next unless defined $event->{$key} && !ref $event->{$key};
    $out{$key} = substr($event->{$key}, 0, $key eq 'last_assistant_message' ? 4000 : 600);
}
$out{is_interrupt} = $event->{is_interrupt} ? JSON::PP::true : JSON::PP::false if exists $event->{is_interrupt};
if (ref $event->{tool_input} eq 'HASH') {
    my %input;
    for my $key (qw(file_path notebook_path command description pattern path url query subagent_type)) {
        my $v = $event->{tool_input}{$key};
        $input{$key} = substr($v, 0, 300) if defined $v && !ref $v;
    }
    $out{tool_input} = \%input;
}
$out{claude_pid} = getppid();   # процесс claude: по нему находим окно приложения
$out{agent} = $ARGV[0] if defined $ARGV[0] && $ARGV[0] eq 'codex';   # хук Codex: скрипт зовётся с аргументом codex
$out{ts} = time;

my $path = "$ENV{HOME}/Library/Application Support/Notchling/events.sock";
my $sock = IO::Socket::UNIX->new(Type => SOCK_STREAM, Peer => $path) or exit 0;
print $sock JSON::PP->new->utf8->canonical->encode(\%out);
close $sock;
exit 0;
